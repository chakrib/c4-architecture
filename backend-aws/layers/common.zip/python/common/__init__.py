# Common utilities for Lambda functions
